"""Render webhook ve dış cron giriş noktası."""

from __future__ import annotations

import asyncio
import logging
import secrets
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request
from telegram import Update

from .bot import build_application
from .config import Settings
from .scheduler import check_active_alarms, check_kap_updates

LOGGER = logging.getLogger(__name__)
settings = Settings.from_env()
application = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global application
    settings.validate()
    application = build_application(settings)
    await application.initialize()
    await application.start()
    if settings.app_base_url:
        webhook_url = f"{settings.app_base_url.rstrip('/')}/telegram/webhook"
        await application.bot.set_webhook(
            url=webhook_url,
            secret_token=settings.telegram_webhook_secret,
            allowed_updates=Update.ALL_TYPES,
        )
        LOGGER.info("Telegram webhook ayarlandı: %s", webhook_url)
    try:
        yield
    finally:
        if application:
            await application.stop()
            await application.shutdown()


app = FastAPI(title="Nexa Telegram Bot", version="0.1.0", lifespan=lifespan)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "nexa"}


@app.post("/telegram/webhook")
async def telegram_webhook(request: Request, x_telegram_bot_api_secret_token: str | None = Header(default=None)) -> dict[str, bool]:
    if application is None:
        raise HTTPException(status_code=503, detail="Bot başlatılmadı")
    expected = settings.telegram_webhook_secret
    if expected and not secrets.compare_digest(x_telegram_bot_api_secret_token or "", expected):
        raise HTTPException(status_code=403, detail="Geçersiz webhook imzası")
    payload = await request.json()
    update = Update.de_json(payload, application.bot)
    await application.process_update(update)
    return {"ok": True}


@app.post("/internal/cron")
async def internal_cron(x_cron_secret: str | None = Header(default=None)) -> dict[str, bool]:
    if not settings.cron_secret or not secrets.compare_digest(x_cron_secret or "", settings.cron_secret):
        raise HTTPException(status_code=403, detail="Geçersiz cron anahtarı")
    if application is None:
        raise HTTPException(status_code=503, detail="Bot başlatılmadı")
    context = type("CronContext", (), {"application": application, "bot": application.bot})()
    await check_active_alarms(context)
    await check_kap_updates(context)
    return {"checked": True}
